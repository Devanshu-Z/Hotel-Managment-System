<?php
    include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Home (Hotel Management)</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">
</head>
<body>
<div id="full">
<div style="background-image:url('img/k2.jpg'); width:100%; height:800px; background-repeat:no-repeat; background-size:cover;">
<div id="header">
<div id="logo">
<h1><font color="white" face="broadway">Kamar-Taj</font></h1>
</div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="index.php">Home</a></li>
<li><a href="bms.php">Book My Stay</a></li>
<li><a href="#">Help</a></li>
<li><a href="contact.php">Contact Us</a></li>
<li><a href="admin/index.php">Admin</a></li>
</font>
</ul>
</div>
</div>
<div id="banner" style="height:200px;">
     <center>
	 <div style="background-color:rgba(128,128,128,0.8); width:60%; height: 80px; margin-bottom: 10px; margin-top:10px;" >
	 <h1 style="text-align:center; color: white;"><font face="broadway">REGISTRATION COMPLETED</font></h1>
	 </div>
	 </center>
</div>
<center>
<div style="background-color:rgb(128,128,128,0.8); width:60%;">
<table>
   <tr>
   <th width="30%" height="50px">Customer ID:</th>
   <td width="30%" height="50px"><?php echo $_GET['id'];?></td>
   </tr>
   <tr>
   <th width="30%" height="50px">Customer Name:</th>
   <td width="30%" height="50px"><?php echo $_GET['name'];?></td>
   </tr>
   <tr>
   <th width="30%" height="50px">Check In Date:</th>
   <td width="30%" height="50px"><?php echo $_GET['cidate'];?></td>
   </tr>
   <tr>
   <th width="30%" height="50px">Check Out Date:</th>
   <td width="30%" height="50px"><?php echo $_GET['codate'];?></td>
   </tr>
   <tr>
   <th width="30%" height="50px">Room No:</th>
   <td width="30%" height="50px"><?php echo $_GET['rno'];?></td>
   </tr>
   <tr>
   <th width="30%" height="50px">Room Type:</th>
   <td width="25%" height="50px">
   <?php
   $rno=$_GET['rno'];
   $q1="select * from room where rno=$rno";
   $run=mysqli_query($a,$q1);
   $row=mysqli_fetch_array($run);
   $rt=$row['type'];
   $rp=$row['price'];
   echo $rt;
   ?>
   </td>
   </tr>
   <tr>
   <th width="30%" height="50px">Room Price:</th>
   <td width="25%" height="50px"><?php echo $rp;?></td>
   </tr>
</table>
</div>
</center>	
</div>	
</div>
</div>
</div>
</body>
</html>