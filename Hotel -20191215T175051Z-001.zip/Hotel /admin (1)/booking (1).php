<?php
  include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">

</head>
<body>
<div id="full">
<div style="background-image:url('img/g2.jpg'); background-size:100% 680px; width:100%; height:680px; background-repeat:no-repeat; background-size:cover">
<div id="header">
<div id="logo">
<h1><font color="white" face="broadway">Kamar-Taj</font></h1>
</div>
<div><button id="btn">|||</button></div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="ahome.php">Home</a></li>
<li><a href="room.php">Room Update</a></li>
<li><a href="booking.php">Booking</a></li>
<li><a href="rd.php">Room Details</a></li>
<li><a href="#">Help</a></li>
<li><a href="index.php">LogOut</a></li>
</font>
</ul>
</div>
</div>
<div id="banner" style="height:50px;"></div>
     <center>
	 <div style="background-color:rgba(128,128,128,0.8); width:60%;">
	 <h1 style="text-align:center; color:white;"><font face="broadway">WELCOME ADMIN</font></h1>
	 </div>
	 <div style="background-color:rgba(255,255,255,0.6); width:100%">
	 <table>
	 <tr>
	 <th width="10%" height="50px">Name
	 </th>
	 <th width="10%" height="50px">Id No.
	 </th>
	 <th width="10%" height="50px">City
	 </th>
	 <th width="10%" height="50px">State
	 </th>
	 <th width="10%" height="50px">email
	 </th>
	 <th width="10%" height="50px">Check In Date
	 </th>
	 <th width="10%" height="50px">Check Out Date
	 </th>
	 <th width="10%" height="50px">Member
	 </th>
	 </tr>
	 <?php
	   $q1="SELECT * FROM `form` WHERE 1";
	   $run=mysqli_query($a,$q1);
	   while($row=mysqli_fetch_array($run))
	   {
		 ?>
		 <tr style="color:black;">
	     <td width="10%" height="50px"><center><?php echo $row['name']?></center></td>
		 <td width="10%" height="50px"><center><?php echo $row['id']?></center></td>
		 <td width="10%" height="50px"><center><?php echo $row['city']?></center></td>
		 <td width="10%" height="50px"><center><?php echo $row['state']?></center></td>
		 <td width="10%" height="50px"><center><?php echo $row['email']?></center></td>
		 <td width="10%" height="50px"><center><?php echo $row['cidate']?></center></td>
		 <td width="10%" height="50px"><center><?php echo $row['codate']?></center></td>
		 <td width="10%" height="50px"><center><?php echo $row['m']?></center></td>
	     </tr>
		 <?php
	   }
	 ?>
	 </table>
	 </div>
	 </center>
</div>
</body>
</html>