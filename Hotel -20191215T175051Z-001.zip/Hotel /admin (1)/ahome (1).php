<?php
  include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">
<style type="text/css">
	div.try{
		background-color:rgba(128,128,128,0.8);
		width:60%; 
		height: 80px; 
		margin-bottom: 10px;
		margin-top:10px; 
		transition: all 1s ease-out;
	}
	div.try:hover {
  width: 70%;
  height: 120px;
  /*-webkit-transform: rotate(180deg); /* Safari */
  transform: scale(1,1.5);
}
</style>
</head>
<body>
<div id="full">
<div style="background-image:url('img/g2.jpg'); background-size:100% 680px; width:100%; height:680px; background-repeat:no-repeat; background-size:cover">
<div id="header">
<div id="logo">
<h1><font color="white" face="broadway">Kamar-Taj</font></h1>
</div>
<div><button id="btn">|||</button></div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="ahome.php">Home</a></li>
<li><a href="room.php">Room Update</a></li>
<li><a href="booking.php">Booking</a></li>
<li><a href="rd.php">Room Details</a></li>
<li><a href="#">Help</a></li>
<li><a href="index.php">LogOut</a></li>
</font>
</ul>
</div>
</div>
<div id="banner" style="height:200px;"></div>
     <center>
	 <div class="try" style="text-align:center; color: white;">
	 <h1><font face="broadway">WELCOME ADMIN</font></h1>
	 </div>
	 </center>
</div>
</body>
</html>