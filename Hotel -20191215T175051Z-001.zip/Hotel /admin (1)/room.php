<?php
   include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Home (Hotel Management)</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">
</head>
<body>
<div id="full">
<div style="background-image:url('img/book2.jpg'); width:100%; height:800px; background-repeat:no-repeat; background-size:cover;">
<div id="header">
<div id="logo">
<h1><font color="white" face="broadway">Kamar-Taj</font></h1>
</div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="ahome.php">Home</a></li>
<li><a href="room.php">Room Update</a></li>
<li><a href="booking.php">Booking</a></li>
<li><a href="rd.php">Room Details</a></li>
<li><a href="#">Help</a></li>
<li><a href="index.php">LogOut</a></li>
</font></ul>
</div>
</div>
<div style="width:100%; height:50px;"></div>
<div id="banner">
<center>
<div id="form" style="background-color: silver; opacity: 0.8; width:40%; height:150px;">
     <form action="room.php" method="post">

     <table style="color:black; font-weight: bold;">
	   <tr>
	      <td>Room No</td>
		  <td><input type="text" name="no" placeholder="Enter Room No" title="Room No"></td>
	   </tr>
	   <tr>
	      <td>Room Type</td>
		  <td><input type="text" name="type" placeholder="Enter Room Type" title="Room Type"></td>
	   </tr>
	   <tr>
	      <td>Room Price</td>
		  <td><input type="text" name="price" placeholder="Enter Room Price" title="Room Price"></td>
	   </tr>
	   <tr>
	   <td></td>
	   <td><input style="width:120px; height:30px; border-radius:20px; opacity:0.8; font-weight: bold; " type="submit" name="submit" value="submit"></td>
	   </tr>
	 </table>
	 </form>
	 <?php
	 if(isset($_POST['submit']))
	 {
		 $rno=$_POST['no'];
		 $type=$_POST['type'];
		 $price=$_POST['price'];
		 if(mysqli_query($a,"INSERT INTO `room`(rno,type,price) VALUES ('$rno','$type','$price')"))
		 {
			  header("Location:rd.php");
		 }
		 else
		 {
			 echo "data not inserted";
		 }
	 }
	 ?>
</div>
</center>
</div>
</div>
</div>
</body>
</html>