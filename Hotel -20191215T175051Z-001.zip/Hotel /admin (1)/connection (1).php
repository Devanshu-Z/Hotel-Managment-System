<?php
$a=mysqli_connect('localhost','root','','hd');
?>