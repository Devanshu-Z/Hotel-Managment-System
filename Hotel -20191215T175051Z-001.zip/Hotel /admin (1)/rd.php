<?php
  include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">

</head>
<body>
<div id="full">
<div style="background-image:url('img/g2.jpg'); background-size:100% 680px; width:100%; height:680px; background-repeat:no-repeat; background-size:cover">
<div id="header">
<div id="logo">
<h1><font color="white" face="Broadway">Kamar-Taj</font></h1>
</div>
<div><button id="btn">|||</button></div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="ahome.php">Home</a></li>
<li><a href="room.php">Room Update</a></li>
<li><a href="booking.php">Booking</a></li>
<li><a href="rd.php">Room Details</a></li>
<li><a href="#">Help</a></li>
<li><a href="index.php">LogOut</a></li>
</font></ul>
</div>
</div>
<div id="banner" style="height:50px;"></div>
     <center>
	 <div style="background-color:rgba(128,128,128,0.8); width:60%;">
	 <h1 style="text-align:center; color:white"><font face="broadway">WELCOME ADMIN</font></h1>
	 </div>
	 <div style="background-color:rgba(255,255,255,0.6); width:100%">
	 <table>
	 <tr>
	 <th width="25%" height="50px">Room No.</th>
	 <th width="25%" height="50px">Room Type</th>
	 <th width="25%" height="50px">Room Price</th>
	 <th width="25%" height="50px">Status</th>
	 <th width="25%" height="50px">Option</th>
	 </tr>
	 <?php
	    $q1="SELECT * FROM `room` WHERE 1";
		$run=mysqli_query($a,$q1);
		while($row=mysqli_fetch_array($run))
		{
			$rno=$row['rno'];
			$rt=$row['type'];
			$rp=$row['price'];
			$st=$row['status'];
	     ?>
		 <tr style="color:black;">
	     <td width="25%" height="50px"><center><?php echo $rno;?></center></td>
		 <td width="25%" height="50px"><center><?php echo $rt;?></center></td>
		 <td width="25%" height="50px"><center><?php echo $rp;?></center></td>
		 <td width="25%" height="50px"><center><?php echo $st;?></center></td>
		 <td><a style="color:black;" href="co.php? rno=<?php echo $rno; ?>" >Check Out</a></td>
	     </tr>
		 <?php
		}
	 ?>
	 
	 </table>
	 </div>
	 </center>
</div>
</body>
</html>