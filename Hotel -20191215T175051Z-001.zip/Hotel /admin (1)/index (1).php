<?php
  include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">

</head>
<body>
<div id="full">
<div style="background-image:url('img/g2.jpg'); background-size:100% 680px; width:100%; height:680px; background-repeat:no-repeat; background-size:cover">
<div id="header">
<div id="logo">
<h1><font color="white" font face="broadway">Kamar-Taj</font></h1>
</div>
<div><button id="btn">|||</button></div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="../index.php">Home</a></li>
<li><a href="../bms.php">Book My Stay</a></li>
<li><a href="#">Help</a></li>
<li><a href="../contact.php">Contact Us</a></li>
</font>
</ul>
</div>
</div>
<div id="banner" style="height:200px;"></div>
<center>
<div style="background:rgba(255,255,255,0.5); width:80%; color:black; font-weight: bold;">
<form action="" method="post">
<table>
<tr>
<td width="50%" height="50px">Username</td>
<td width="50%" height="50px"><input type="text" name="un" placeholder="Enter Username" title="Username"></td>
</tr>
<tr>
<td width="50%" height="50px">Password</td>
<td width="50%" height="50px"><input type="password" name="pw" placeholder="Enter Password" title="Password"></td>
</tr>
<tr>
<td></td>
<td><input style="border-radius:20px; opacity:0.7; width:120px; height:30px;"type="submit" name="login" value="Login" title="Login"></td>
</tr>
</table>
</form>
<?php
      if(isset($_POST['login']))
	  {
		  $un=$_POST['un'];
		  $pw=$_POST['pw'];
		  $q1="SELECT * FROM `admin` WHERE 1";
		  $run=mysqli_query($a,$q1);
		  $row=mysqli_fetch_array($run);
		  $u=$row['un'];
		  $p=$row['pw'];
		  if($un==$u&&$pw==$p)
		  {
			  header("Location:ahome.php");
		  }
		  else
		  {
			 
			  header("Location:index.php");
			  echo "Wrong Username Or Password!";
		  }
	  }
?>
</div>
</center>
</div>
</body>
</html>