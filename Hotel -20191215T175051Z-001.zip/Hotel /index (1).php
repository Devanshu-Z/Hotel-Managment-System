<!DOCTYPE html>
<html>
<head>
<title>Home Kamar-Taj</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">
<script type="text/javascript" src="jquery/jquery.js"></script>
<script type="text/javascript">
     $(document).ready(function()
	 {
		 $('#btn').click(function(){
			 $('#nav').slideToggle();
		 });
	 });
</script>
</head>
<body>
<div id="full">
<div style="background-image:url('img/ht.jpg'); width:100%; height:800px; background-repeat:no-repeat; background-size:cover">
<div id="header">
<div id="logo">
<h1><font color="white" face="broadway">Kamar-Taj</font></h1>
</div>
<div><button style="display:none;" id="btn">|||</button></div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="index.php">Home</a></li>
<li><a href="bms.php">Book My Stay</a></li>
<li><a href="#">Help</a></li>
<li><a href="contact.php">Contact Us</a></li>
<li><a href="admin/index.php">Admin</a></li>
</font>
</ul>
</div>
</div>
<div id="banner"></div>
</div>
<div id="f1">
<form action="r1.php" method="get">
<table align="center">
    <tr>
       <th width="20%" height="50px">Destination</th>
	   <th width="20%" height="50px">Check-In</th>
	   <th width="20%" height="50px">Check-Out</th>
	   <th width="20%" height="50px">Room</th>
	   <td rowspan="2"><input style="width:120px; height:30px; border-radius:20px; opacity:0.9;" type="submit" value="Check" name="submit"></td>
    </tr>
	<tr>
       <th width="20%" height="50px">
       	<select name="Destination">
	   <option>Goa</option>
	   <option>Delhi</option>
	   <option>Mumbai</option>
	   <option>Kolkata</option>
	   </select></th>
	   <th width="20%" height="50px"><input type="date" name="ci" min="2019-11-18"></th>
	   <th width="20%" height="50px"><input type="date" name="co" min="2019-11-19"></th>
	   <th width="20%" height="50px">
	   <select name="room">
	   <option>1</option>
	   <option>2</option>
	   <option>3</option>
	   <option>4</option>
	   <option>5</option>
	   </select>
	   </th>
    </tr>
</table>
</div>
<div id="welcome">
    <h1 align="center" style="color:black; ">Welcome To Kamar-Taj</h1>
	<center>
	<font size="4" color="black">Kamar-Taj is the right choice for visitors who are searching for a combination of charm, peace and quiet,<br>and a convenient position from which to explore nature.<br>The Xao family who are the heridetry owners of this place and their staff offer an attentive, personalized service<br>and are always available to offer any help to guests.<br>
	The hotel is arranged on three floors.<br>On the ground floor, apart from the reception, there is a comfortable pool-side lounge where you can sit and drink tea, or just read.<br>There is also a splendid terrace, where, you can relax and immerge yourself from morning onwards in the calm atmosphere.<br>
	</font>
	<h2 style="color:black; ">OUR VENUES</h2>
	</center>
</div>
<div id="g1">
    <div id="one"><img src="img/h1.jpg" height="250px" width="100%">
	<center>
	<h2 style="color:black;">GOA</h2>
	<font color="black">Enjoy the Calm and Harmonious Sound of The Ocean<br>with freshly prepared Coconut water.<br>The Divinity of the Churches and<br> the Aroma of Indias best Seafood.  </font><br>
	</center>
	</div>
	<div id="two"><img src="img/h2.jpg" height="250px" width="100%">
	<center>
	<h2 style="color:black;">MUMBAI</h2>
	<font color="black">Travel in the Local Trains <br>and feel the Vibes of the Marine Drive.<br> Salute at The Gateway of India and<br> Listen to the Symphony at Opera House</font><br>
	</center>
	</div>
	<div id="three"><img src="img/h3.jpg" height="250px" width="100%">
	<center>
	<h2 style="color:black;">DELHI</h2>
	<font color="black">Enjoy your stay in the Capital where you<br>can get the fragrance of Independence Movement and <br>also the Flavours of Indias Political Power.</font><br>
	</center>
	</div>
</div>
</div>
</body>
</html>