<!DOCTYPE html>
<html>
<head>
<title>Home (Hotel Management)</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">

</head>
<body>
<div id="full">
<div style="background-image:url('img/k2.jpg'); background-size:100% 680px; width:100%; height:680px; background-repeat:no-repeat; background-size:cover">
<div id="header">
<div id="logo">
<h1><font color="white" face="broadway">Kamar-Taj</font></h1>
</div>
<div><button style="display:none;" id="btn">|||</button></div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="index.php">Home</a></li>
<li><a href="bms.php">Book My Stay</a></li>
<li><a href="#">Help</a></li>
<li><a href="contact.php">Contact Us</a></li>
<li><a href="admin/index.php">Admin</a></li>
</font>
</ul>
</div>
</div>
<div id="banner" style="height:200px;"></div>
<center>
<div style="background:rgba(255,255,255,0.6); width:80%;">
<form action="r1.php" method="get">
<table>
    <tr>
       <th width="20%" height="50px">Destination</th>
	   <th width="20%" height="50px">Check-In</th>
	   <th width="20%" height="50px">Check-Out</th>
	   <th width="20%" height="50px">Room</th>
	   <td rowspan="2"><input style="width:120px; height:30px; border-radius:20px; opacity:0.9;" type="submit" value="Check" name="submit"></td>
    </tr>
	<tr>
       <th width="20%" height="50px">
       	<select name="Destination">
	   <option>Goa</option>
	   <option>Delhi</option>
	   <option>Mumbai</option>
	   <option>Kolkata</option>
	   </select></th>
	   <th width="20%" height="50px"><input type="date" name="ci"></th>
	   <th width="20%" height="50px"><input type="date" name="co"></th>
	   <th width="20%" height="50px">
	   <select name="room">
	   <option>1</option>
	   <option>2</option>
	   <option>3</option>
	   <option>4</option>
	   <option>5</option>
	   </select>
	   </th>
    </tr>
</table>
</form>
</div>
</center>
</div>
</body>
</html>