<?php
   include("connection.php");
   $r=$_GET['room'];
   $ci=$_GET['ci'];
   $co=$_GET['co'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Home (Hotel Management)</title>
<link href="css/styles.css" rel="stylesheet" type="text/css"> 
<link href="img/logo.png" type="img/icon" rel="icon">
</head>
<body>
<div id="full">
<div style="background-image:url('img/book2.jpg'); width:100%; height:800px; background-repeat:no-repeat; background-size:cover;">
<div id="header">
<div id="logo">
<h1><font color="white" face="broadway">Kamar-Taj</font></h1>
</div>
<div id="nav">
<ul><font face="comic sans ms">
<li><a href="index.php">Home</a></li>
<li><a href="bms.php">Book My Stay</a></li>
<li><a href="#">Help</a></li>
<li><a href="contact.php">Contact Us</a></li>
<li><a href="admin/index.php">Admin</a></li>
</font>
</ul>
</div>
</div>
<div style="width:100%; height:50px;"></div>
<div id="banner">
	<center>
<div id="form"  style="background:rgb(155,155,155); opacity: 0.6; width:50%; height:auto; font-weight:bold; ">
	
     <form action="r1.php" method="post">
     <table style="color:black; ">
	 <?php
	      $q1="select * from room where status='UNBOOK'";
		  $run=mysqli_query($a,$q1);
		  $num=mysqli_num_rows($run);
		  if($r<=$num)
		  {
			  ?>
			  <tr>
				<td >Status</td>
				<td ><input type="text" name="status" value="Available" title="status" disabled="disabled"</td>
			  </tr>
			  <tr>
				<td>Name</td>
				<td><input type="text" name="name" placeholder="Enter Name" title="Name"></td>
				<td>ID no.</td>
				<td><input type="text" name="idno" placeholder="Enter ID" title="ID" required="required"></td>
			  </tr>
			  <tr>
				<td>Address</td>
				<td><input type="text" name="address" placeholder="Enter Address" title="Address"></td> 
			  </tr>
		      <tr>
				<td>City</td>
				<td><input type="text" name="city" placeholder="Enter City" title="City"></td> 
			  </tr>
			   <tr>
				<td>State</td>
				<td><input type="text" name="state" placeholder="Enter State" title="State"></td> 
			  </tr>
	          <tr>
				<td>Email</td>
				<td><input type="email" name="email" placeholder="Enter Email" title="Email"></td>
	          </tr>
	          <tr>
				<td>Check In Date</td>
				<td><input type="date" name="coin" value="<?php echo $ci;?>" title="Check In"></td>
				<td>Check Out Date</td>
				<td><input type="date" name="coout" value="<?php echo $co;?>" title="Check Out"></td>
	          </tr>
	          <tr>
				<td>Number Of Members</td>
				<td><input type="number" name="members" placeholder="Members" title="Members" min="1" max="3"></td>
	          </tr>
	          <tr>
				<td></td>
				<td><input style="width:120px; height:30px; border-radius:20px; opacity:0.8; " type="submit" name="submit" value="submit"></td>
	          </tr>
			  <?php
		  }
		  else
		  {
			  ?>
			  <tr>
	            <td>Status</td>
		        <td><input type="text" name="status" value="Unavailable" title="status" disabled="disabled"</td>
	          </tr>
			  <?php
		  }
	 ?>  
	 </table>
	 </form>

	 <?php
	 if(isset($_POST['submit']))
	 {
		 $name=$_POST['name'];
		 $idno=$_POST['idno'];
		 $addr=$_POST['address'];
		 $city=$_POST['city'];
		 $dis=$_POST['dis'];
		 $state=$_POST['state'];
		 $email=$_POST['email'];
		 $coin=$_POST['coin'];
		 $coout=$_POST['coout'];
		 $members=$_POST['members'];
		 
		 $q1="select * from room where status='UNBOOK'";
		 $run=mysqli_query($a,$q1);
		 $row=mysqli_fetch_array($run);
		 $rno=$row['rno'];
		 if(mysqli_query($a,"INSERT INTO `form`(id,name,addr,city,dis,state,email,cidate,codate,m) VALUES ('$idno','$name','$addr','$city','$dis','$state','$email','$coin','$coout','$members')"))
		 {
			 mysqli_query($a,"INSERT INTO `booking`(id,name,cidate,rno) VALUES ('$idno','$name','$coin','$rno')");
			 mysqli_query($a,"update room set status='BOOK' where rno=$rno");
			 $newlocation="f1.php?id=$idno&name=$name&cidate=$coin&codate=$coout&rno=$rno";
			 header("Location:$newlocation");
		 }
		 else
		 {
			 echo "data not inserted";
		 }
	 }
	 ?>
</div>
</center>
</div>
</div>
</div>
</body>
</html>